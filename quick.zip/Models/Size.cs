﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace onlineshop.Models
{
    public class Size
    {
        public List<string> size { get; set; }
    }

}
